package ru.kotenokdev.pvprooms.config;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import org.bukkit.configuration.file.YamlConfiguration;
import ru.kotenokdev.pvprooms.PvPRoomsAPI;

public class Config {

    @Getter private Map<Long, Component> remainTimeNotify = new HashMap<>();
    @Getter private final Material closeEntryWithMaterial;
    @Getter private Component PvPStarted;
    @Getter private long time;
    @Getter private long secondsToTakeItems;
    @Getter private Component youWin;
    @Getter private Component youLose;
    @Getter private Location lobby;
    @Getter private Component leftRoom;
    @Getter private Component joinRoom;
    @Getter private Component roomIsFull;
    @Getter private ConfigurationSection roomsSection;
    @Getter private boolean autoRespawn;

    public Config(){
        File file = new File(PvPRoomsAPI.getInstance().getDataFolder(), "config.yml");
        if (!file.exists()){
            PvPRoomsAPI.getInstance().saveResource("config.yml", false);
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        closeEntryWithMaterial = Material.getMaterial(config.getString("close-entry-with-material", "BARRIER").toUpperCase());
        time = config.getLong("time", 300L);
        secondsToTakeItems = config.getLong("seconds-to-take-items", 15L);
        lobby = readLocation(config.getConfigurationSection("lobby"));
        ConfigurationSection messagesSection = config.getConfigurationSection("messages");
        PvPStarted = message(messagesSection, "pvp-started");
        youWin = message(messagesSection, "you-win");
        youLose = message(messagesSection, "you-lose");
        leftRoom = message(messagesSection, "left-room");
        joinRoom = message(messagesSection, "join-room");
        roomIsFull = message(messagesSection, "room-is-full");
        ConfigurationSection notify = messagesSection.getConfigurationSection("notify");
        for (String key : notify.getKeys(false)){
            long notifyTime = 0;
            try {
                notifyTime = Long.parseLong(key);
            } catch(Exception e){ continue; }
            Component msg = message(notify, key);
            remainTimeNotify.put(notifyTime, msg);
        }
        autoRespawn = config.getBoolean("auto-respawn", false);
        roomsSection = config.getConfigurationSection("rooms");
    }

    private final Location readLocation(ConfigurationSection config){
        World world = Bukkit.getWorld(config.getString("world", "world"));
        int x = config.getInt("x", 0);
        int y = config.getInt("y", 0);
        int z = config.getInt("z", 0);
        return new Location(world, x, y, z);
    }

    private final Component message(ConfigurationSection config, String path){
        return MiniMessage.miniMessage().deserialize(config.getString(path, ""));
    }
}
