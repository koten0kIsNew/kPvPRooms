package ru.kotenokdev.pvprooms.manager;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import ru.kotenokdev.pvprooms.PvPRoomsAPI;
import ru.kotenokdev.pvprooms.config.Config;

public class PvPRoom {

    private RoomStage stage;
    private RoomEntry entry;
    private Location pos1;
    private Location pos2;
    private Player player;
    private Player enemy;
    private long timer; //in seconds

    public PvPRoom(ConfigurationSection config){
        ConfigurationSection entrySection = config.getConfigurationSection("entry");
        entry = new RoomEntry(readLocation(entrySection.getConfigurationSection("pos1")), readLocation(entrySection.getConfigurationSection("pos2")));
        pos1 = readLocation(config.getConfigurationSection("pos1"));
        pos2 = readLocation(config.getConfigurationSection("pos2"));
        timer = -1;
        stage = RoomStage.WAITING;
    }

    private final Location readLocation(ConfigurationSection config){
        World world = Bukkit.getWorld(config.getString("world", "world"));
        int x = config.getInt("x", 0);
        int y = config.getInt("y", 0);
        int z = config.getInt("z", 0);
        return new Location(world, x, y, z);
    }

    public void startPvP(){
        stage = RoomStage.PVP;
        Config config = PvPRoomsAPI.getInstance().getConf();
        player.sendMessage(config.getPvPStarted());
        enemy.sendMessage(config.getPvPStarted());
        timer = config.getTime();
        entry.close();
    }

    public void endPvP(Player loser){
        if (stage.equals(RoomStage.WAITING)){
            player = null;
            enemy = null;
            openPvPRoom();
            return;
        }
        if (player == null || enemy == null) {
            timer = -1;
            openPvPRoom();
            enemy = null;
            player = null;
            return;
        }
        stage = RoomStage.ENDING;
        Config config = PvPRoomsAPI.getInstance().getConf();
        timer = config.getSecondsToTakeItems();
        if (player.equals(loser)) {
            player.sendMessage(config.getYouLose());
            enemy.sendMessage(config.getYouWin());
            player = null;
        }
        else {
            enemy.sendMessage(config.getYouLose());
            player.sendMessage(config.getYouWin());
            enemy = null;
        }
    }

    public void openPvPRoom(){
        Config config = PvPRoomsAPI.getInstance().getConf();
        if (player != null) {
            player.teleport(config.getLobby());
            player.sendMessage(config.getLeftRoom());
        }
        if (enemy != null) {
            enemy.teleport(config.getLobby());
            enemy.sendMessage(config.getLeftRoom());
        }
        stage = RoomStage.WAITING;
        entry.open();
    }

    public void teleportToLobbyIfCannotStay(Player human){
        Config config = PvPRoomsAPI.getInstance().getConf();
        if (stage.equals(RoomStage.WAITING)) {
            if (player == null) {
                player = human;
                human.sendMessage(config.getJoinRoom());
                return;
            }
            if (player.equals(human)) return;
            human.sendMessage(config.getJoinRoom());
            enemy = human;
            startPvP();
            return;
        }
        if ((player == null || !player.equals(human)) && (enemy == null || !enemy.equals(human))) {
            human.teleport(config.getLobby());
            human.sendMessage(config.getRoomIsFull());
        }
    }

    public void everySecond(){
        for (Player p : Bukkit.getOnlinePlayers()){
            if (inRoom(p)) teleportToLobbyIfCannotStay(p);
            else if ((player != null && player.equals(p)) || (enemy != null && enemy.equals(p))) endPvP(p);
        }
        if (stage.equals(RoomStage.WAITING)) return;
        timer--;
        if (timer < 1){
            openPvPRoom();
            return;
        }
        if (stage.equals(RoomStage.ENDING)){
            Component msg = PvPRoomsAPI.getInstance().getConf().getRemainTimeNotify().get(0L);
            if (msg != null){
                if (player != null) player.sendMessage(msg);
                if (enemy != null) enemy.sendMessage(msg);
            }
            return;
        }
        Component msg = PvPRoomsAPI.getInstance().getConf().getRemainTimeNotify().get(timer);
        if (msg != null){
            player.sendMessage(msg);
            enemy.sendMessage(msg);
        }
        if (!inRoom(player)) {
            endPvP(player);
        }
        if (!inRoom(enemy)) {
            endPvP(enemy);
        }
    }

    private boolean inRoom(Player p){
        Location location = p.getLocation();
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();
        if (x >= pos1.getBlockX() && x <= pos2.getBlockX())
            if (y >= pos1.getBlockY() && y <= pos2.getBlockY())
                if (z >= pos1.getBlockZ() && z <= pos2.getBlockZ()) return true;
        return false;
    }

    public void endPvPIfCan(Player loser){
        if (stage.equals(RoomStage.WAITING)) return;
        if ((player == null || !player.equals(loser) && (enemy == null || !enemy.equals(loser)))) return;
        endPvP(loser);
    }
}
