package ru.kotenokdev.pvprooms.manager;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import ru.kotenokdev.pvprooms.PvPRoomsAPI;

public record RoomEntry(Location pos1, Location pos2) {

    public void open() {
        fill(Material.AIR);
    }

    public void close(){
        fill(PvPRoomsAPI.getInstance().getConf().getCloseEntryWithMaterial());
    }

    private void fill(Material material){
        World world = pos1.getWorld();
        int minX = pos1.getBlockX();
        int minY = pos1.getBlockY();
        int minZ = pos1.getBlockZ();
        int maxX = pos2.getBlockX() + 1;
        int maxY = pos2.getBlockY() + 1;
        int maxZ = pos2.getBlockZ() + 1;
        for (int x = minX;x < maxX;x++)
            for (int y = minY;y < maxY;y++)
                for (int z = minZ;z < maxZ;z++){
                    new Location(world, x, y, z).getBlock().setType(material);
                }
    }
}
