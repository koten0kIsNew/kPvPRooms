package ru.kotenokdev.pvprooms.manager;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.kotenokdev.pvprooms.PvPRoomsAPI;

import java.util.HashSet;
import java.util.Set;

public class RoomsContainer implements Listener {

    private final Set<PvPRoom> rooms = new HashSet<>();

    public RoomsContainer(){
        ConfigurationSection roomsSection = PvPRoomsAPI.getInstance().getConf().getRoomsSection();
        for (String roomname : roomsSection.getKeys(false)){
            ConfigurationSection roomSection = roomsSection.getConfigurationSection(roomname);
            PvPRoom room = new PvPRoom(roomSection);
            room.openPvPRoom();
            rooms.add(room);
        }

        Bukkit.getScheduler().runTaskTimer(PvPRoomsAPI.getInstance(), () -> {
            for (PvPRoom room : rooms){
                room.everySecond();
            }
        }, 20L, 20L);

        Bukkit.getPluginManager().registerEvents(this, PvPRoomsAPI.getInstance());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event){
        if (PvPRoomsAPI.getInstance().getConf().isAutoRespawn())
            Bukkit.getScheduler().runTaskLater(PvPRoomsAPI.getInstance(), () -> event.getPlayer().spigot().respawn(), 3L);
        else {
            for (PvPRoom room : rooms){
                room.endPvPIfCan(event.getPlayer());
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event){
        for (PvPRoom room : rooms){
            room.endPvPIfCan(event.getPlayer());
        }
    }
}
