package ru.kotenokdev.pvprooms.manager;

public enum RoomStage {

    WAITING,
    PVP,
    ENDING;
}
