package ru.kotenokdev.pvprooms;

import org.bukkit.plugin.java.JavaPlugin;

import lombok.Getter;
import ru.kotenokdev.pvprooms.config.Config;
import ru.kotenokdev.pvprooms.manager.RoomsContainer;

public class PvPRoomsAPI extends JavaPlugin {

    @Getter private static PvPRoomsAPI instance;
    @Getter private Config conf;

    public void onEnable(){
        instance = this;
        conf = new Config();
        new RoomsContainer();
    }
}
