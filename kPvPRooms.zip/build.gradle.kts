plugins {
    id("java")
}

group = "ru.kotenokdev"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    testImplementation(platform("org.junit:junit-bom:5.10.0"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    implementation("io.papermc.paper:paper-api:1.21.8-R0.1-SNAPSHOT")
    implementation("org.projectlombok:lombok:1.18.42")
    annotationProcessor("org.projectlombok:lombok:1.18.42")
}

tasks.register<Copy>("copyJar"){
    from ("/build/libs/${project.name}-${project.version}.jar")
    into ("C:\\Users\\kotenok_dev\\Desktop\\test\\plugins")
}

tasks.test {
    useJUnitPlatform()
}

tasks.build {
    finalizedBy("copyJar")
}